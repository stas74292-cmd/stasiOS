Generated disk images are kept outside the normal source tree for GitHub. Publish them as GitHub Release assets instead of committing large binaries to the repository.
