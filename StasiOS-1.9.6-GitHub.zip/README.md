# StasiOS

StasiOS is an experimental 64-bit operating-system project targeting Intel/AMD x86-64 hardware.

## Current version: 1.9.6

This release is a PE64 loader prototype. It is **not yet a Windows compatibility layer** and does not run arbitrary Windows `.exe` files.

### Current goals
- BIOS/Legacy boot
- x86-64 kernel foundation
- FAT32 storage support (prototype)
- ELF64 loading experiments
- PE32+ / PE64 parsing and section loading experiments
- future Windows, Linux and macOS application compatibility layers

## Repository layout

```text
boot/       bootloader sources
kernel/     kernel sources
loader/     executable-format loaders
fs/         filesystem code
scripts/    build tools
images/     locally generated disk images (not committed)
```

## Building

The project is experimental. The boot source currently serves as the 1.9.6 prototype source and may require a cross-compiler/toolchain depending on the host environment.

## Roadmap

- 1.9.7 — PE relocations and Import Table
- 2.0 — process/address-space infrastructure
- 2.x — Win64 compatibility layer
- later — ELF/Linux and Mach-O/macOS compatibility

## License

MIT License. See `LICENSE`.
